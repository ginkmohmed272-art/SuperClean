package com.superclean.app

import android.app.ActivityManager
import android.content.Context
import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { SuperCleanApp(this) } }
}

@Composable
fun SuperCleanApp(context: Context) {
    var tab by remember { mutableStateOf(0) }
    var mode by remember { mutableStateOf("Balanced") }
    var message by remember { mutableStateOf("جاهز لتحليل جهازك") }
    val dark = darkColorScheme(primary = Color(0xFF7C4DFF), background = Color(0xFF10111A), surface = Color(0xFF191B28))
    MaterialTheme(colorScheme = dark) {
        Scaffold(bottomBar = { NavigationBar { listOf("الرئيسية", "الألعاب", "الحساسية", "الإعدادات").forEachIndexed { i, title -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(title) }) } } }) { pad ->
            LazyColumn(modifier = Modifier.padding(pad).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item { Text("SuperClean", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold); Text("Smart Gaming Center", color = Color.LightGray) }
                when (tab) {
                    0 -> { item { DeviceCard(context) }; item { Text("وضع الأداء", style = MaterialTheme.typography.titleLarge) }; item { ModeButtons(mode) { mode = it; message = "تم اختيار وضع $it" } }; item { Button(onClick = { message = "تم تنفيذ فحص آمن: لا يمكن للتطبيق إغلاق تطبيقات النظام تلقائيًا بدون صلاحيات خاصة." }, modifier = Modifier.fillMaxWidth()) { Text("تحليل وتحسين آمن") } }; item { Text(message) } }
                    1 -> { item { Text("Game Turbo", style = MaterialTheme.typography.headlineMedium) }; item { Text("أضف ألعابك هنا. يمكن تطوير تشغيل الألعاب والشريط العائم لاحقًا بصلاحيات النظام المناسبة.") }; item { Button(onClick = { message = "ميزة مراقبة FPS تحتاج دعمًا خاصًا أو تكاملًا مع اللعبة." }) { Text("فحص إمكانية عرض FPS") } }; item { Text(message) } }
                    2 -> { item { Text("Free Fire Sensitivity", style = MaterialTheme.typography.headlineMedium) }; item { Text("اقتراح مبدئي لجهاز 3GB RAM: ابدأ بحساسية متوسطة ثم عدّلها حسب استجابة اللمس.") }; item { Button(onClick = { message = "اقتراح: General 90 | Red Dot 85 | 2x 75 | 4x 65 | زر إطلاق 48% — هذه نقطة بداية وليست ضمانًا." }) { Text("توليد اقتراح") } }; item { Text(message) } }
                    3 -> { item { Text("الإعدادات", style = MaterialTheme.typography.headlineMedium) }; item { Text("الوضع الداكن مفعل افتراضيًا. يمكن إضافة الثيمات والإشعارات وإعدادات متقدمة في الإصدارات القادمة.") } }
                }
            }
        }
    }
}

@Composable fun ModeButtons(current: String, onPick: (String) -> Unit) { Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) { listOf("Power Save", "Balanced", "Pro Gamer").forEach { TextButton(onClick = { onPick(it) }) { Text(if (current == it) "✓ $it" else it) } } } }

@Composable fun DeviceCard(context: Context) {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val info = ActivityManager.MemoryInfo(); am.getMemoryInfo(info)
    val total = info.totalMem / 1024 / 1024
    val free = info.availMem / 1024 / 1024
    Card { Column(Modifier.padding(16.dp)) { Text("معلومات الجهاز", style = MaterialTheme.typography.titleLarge); Text("الموديل: ${Build.MANUFACTURER} ${Build.MODEL}"); Text("Android: ${Build.VERSION.RELEASE}"); Text("RAM الكلية: ${total}MB"); Text("RAM المتاحة: ${free}MB"); Text("المعالج: معلومات المعالج التفصيلية قد تختلف حسب إصدار أندرويد") } }
}
