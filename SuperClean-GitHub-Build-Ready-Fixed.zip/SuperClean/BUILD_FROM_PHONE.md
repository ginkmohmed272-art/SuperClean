# SuperClean - build from phone

This project is configured for GitHub Actions.

1. Create a GitHub repository.
2. Upload the CONTENTS of this folder (the `settings.gradle.kts` file must be in the repository root).
3. Open Actions.
4. Run **Build SuperClean APK**.
5. Open the completed workflow run and download the artifact named `SuperClean-debug-apk`.

Important:
- This is a functional starter app, not a full system-level Game Booster.
- Android does not allow ordinary apps to freely clear RAM, change CPU/GPU performance, or show real FPS over every game.
- The app only uses permissions and APIs available to normal apps.
